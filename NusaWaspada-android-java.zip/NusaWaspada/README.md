# NusaWaspada 🌍

**Aplikasi Android prakiraan cuaca BMKG, informasi gempa bumi, dan kesiapsiagaan bencana untuk Indonesia.**

[![Build](https://github.com/YOUR_USERNAME/NusaWaspada/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR_USERNAME/NusaWaspada/actions)

---

## Fitur

| Tab | Deskripsi |
|-----|-----------|
| 🏠 Beranda | Ringkasan cuaca, gempa, jam perangkat, dan navigasi cepat |
| 🌤️ Cuaca | Prakiraan cuaca BMKG per desa/kelurahan via GPS atau kode adm4 manual |
| 🌍 Gempa | Gempa terbaru dan daftar gempa dirasakan dari BMKG |
| ⚠️ Bencana | Panduan kesiapsiagaan: gempa, banjir, cuaca ekstrem, tanah longsor |
| 📋 Panduan | Cara pakai aplikasi dan informasi sumber data |

---

## Sumber Data

- **Prakiraan cuaca**: `api.bmkg.go.id/publik/prakiraan-cuaca?adm4=`
- **Gempa terbaru**: `data.bmkg.go.id/DataMKG/TEWS/autogempa.json`
- **Gempa dirasakan**: `data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json`
- **Geocoding**: OpenStreetMap Nominatim
- **Indeks kode wilayah**: `raw.githubusercontent.com/dwirx/bmkg-api/main/base.csv`

---

## Cara Build

### Persyaratan
- Android Studio Hedgehog atau lebih baru
- JDK 17
- Android SDK 34

### Build via Android Studio
1. Clone repo ini
2. Buka dengan Android Studio
3. Sync Gradle
4. Klik **Run** atau **Build > Build APK**

### Build via Command Line
```bash
git clone https://github.com/YOUR_USERNAME/NusaWaspada.git
cd NusaWaspada
chmod +x gradlew
./gradlew assembleDebug
# APK tersedia di: app/build/outputs/apk/debug/app-debug.apk
```

---

## Build Otomatis via GitHub Actions

Setiap push ke branch `main` akan otomatis membangun APK debug dan tersedia sebagai **Artifact** di tab Actions GitHub selama 14 hari.

Langkah:
1. Push kode ke GitHub
2. Buka tab **Actions**
3. Pilih workflow **Build NusaWaspada APK**
4. Setelah selesai, klik **Artifacts** → Download `NusaWaspada-debug.zip`

---

## Struktur Proyek

```
NusaWaspada/
├── .github/workflows/build.yml     ← GitHub Actions CI
├── app/
│   └── src/main/
│       ├── java/id/nusawaspada/
│       │   ├── ui/
│       │   │   ├── MainActivity.java
│       │   │   ├── beranda/BerandaFragment.java
│       │   │   ├── cuaca/CuacaFragment.java + CuacaViewModel.java + CuacaAdapter.java
│       │   │   ├── gempa/GempaFragment.java + GempaViewModel.java + GempaAdapter.java
│       │   │   ├── bencana/BencanaFragment.java
│       │   │   └── panduan/PanduanFragment.java
│       │   └── data/
│       │       ├── api/BmkgRepository.java
│       │       ├── api/GeocodingHelper.java
│       │       ├── api/RegionIndexHelper.java
│       │       └── model/CuacaData.java + GempaModel.java + RegionInfo.java
│       └── res/
│           ├── layout/     ← Semua layout XML
│           ├── navigation/ ← nav_graph.xml
│           ├── menu/       ← bottom_nav_menu.xml
│           ├── values/     ← colors, strings, themes
│           └── drawable/   ← bg_status.xml, ic_launcher
└── README.md
```

---

## Izin Aplikasi

| Izin | Keperluan |
|------|-----------|
| `INTERNET` | Mengambil data BMKG dan geocoding |
| `ACCESS_FINE_LOCATION` | GPS untuk mendeteksi desa/kelurahan |
| `ACCESS_COARSE_LOCATION` | Fallback lokasi kasar |

---

## Catatan Penting

- Data cuaca **adalah prakiraan**, bukan pengukuran langsung.
- Prakiraan hanya ditampilkan setelah kode adm4 dan nama desa **terverifikasi** dari respons BMKG.
- Untuk keselamatan jiwa, selalu ikuti **peringatan resmi BMKG, BPBD, dan pemerintah setempat**.

---

## Lisensi

Proyek ini bersifat open-source. Data BMKG wajib dicantumkan sebagai sumber.
