@if "%DEBUG%"=="" @echo off
@rem Gradle startup script for Windows
@rem See README.md - generate actual gradlew with Android Studio or Gradle wrapper task
set JAVACMD=java
%JAVACMD% -jar "%~dp0gradle\wrapper\gradle-wrapper.jar" %*
