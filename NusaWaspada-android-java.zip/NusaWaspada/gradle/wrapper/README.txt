CATATAN PENTING:
File gradle-wrapper.jar tidak disertakan karena ukurannya besar (~60KB binary).

Cara mendapatkannya:
1. Buka proyek ini di Android Studio → otomatis diunduh
2. ATAU jalankan: gradle wrapper --gradle-version 8.6
3. ATAU clone dari: https://github.com/gradle/gradle

Setelah gradle-wrapper.jar ada di folder ini, proyek siap di-build.
