package id.nusawaspada.ui.beranda;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import id.nusawaspada.R;
import id.nusawaspada.databinding.FragmentBerandaBinding;
import id.nusawaspada.ui.cuaca.CuacaViewModel;
import id.nusawaspada.ui.gempa.GempaViewModel;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class BerandaFragment extends Fragment {

    private FragmentBerandaBinding binding;
    private Handler clockHandler;
    private Runnable clockRunnable;
    private CuacaViewModel cuacaViewModel;
    private GempaViewModel gempaViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentBerandaBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        cuacaViewModel = new ViewModelProvider(requireActivity()).get(CuacaViewModel.class);
        gempaViewModel = new ViewModelProvider(requireActivity()).get(GempaViewModel.class);

        startClock();

        binding.btnPeriksaLokasi.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.navigation_cuaca));

        binding.btnLihatCuaca.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.navigation_cuaca));

        binding.btnPeriksaGempa.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.navigation_gempa));

        cuacaViewModel.getRingkasanCuaca().observe(getViewLifecycleOwner(), ringkasan -> {
            if (ringkasan != null) {
                binding.tvHomeCuaca.setText(ringkasan);
            }
        });

        cuacaViewModel.getNamaLokasi().observe(getViewLifecycleOwner(), lokasi -> {
            if (lokasi != null) {
                binding.tvHomeLokasi.setText("Lokasi: " + lokasi);
            }
        });

        gempaViewModel.getRingkasanGempa().observe(getViewLifecycleOwner(), ringkasan -> {
            if (ringkasan != null) {
                binding.tvHomeGempa.setText(ringkasan);
            }
        });
    }

    private void startClock() {
        clockHandler = new Handler(Looper.getMainLooper());
        clockRunnable = new Runnable() {
            @Override
            public void run() {
                if (binding != null) {
                    String waktu = new SimpleDateFormat("EEEE, dd MMMM yyyy HH:mm:ss",
                            new Locale("id", "ID")).format(new Date());
                    binding.tvClock.setText("Waktu perangkat: " + waktu);
                    clockHandler.postDelayed(this, 1000);
                }
            }
        };
        clockHandler.post(clockRunnable);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (clockHandler != null) clockHandler.removeCallbacks(clockRunnable);
        binding = null;
    }
}
