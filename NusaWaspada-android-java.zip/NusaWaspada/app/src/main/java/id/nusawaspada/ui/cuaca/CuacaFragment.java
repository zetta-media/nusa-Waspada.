package id.nusawaspada.ui.cuaca;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import id.nusawaspada.databinding.FragmentCuacaBinding;
import id.nusawaspada.data.api.GeocodingHelper;
import id.nusawaspada.data.api.RegionIndexHelper;
import id.nusawaspada.data.model.RegionInfo;

public class CuacaFragment extends Fragment {

    private FragmentCuacaBinding binding;
    private CuacaViewModel viewModel;
    private FusedLocationProviderClient fusedLocationClient;

    private final ActivityResultLauncher<String[]> locationPermLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean granted = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION))
                        || Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                if (granted) {
                    dapatkanLokasi();
                } else {
                    viewModel.setStatusLokasi("Izin lokasi ditolak. Aktifkan izin lokasi di pengaturan.");
                }
            });

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentCuacaBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(CuacaViewModel.class);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        viewModel.getStatusLokasi().observe(getViewLifecycleOwner(), s -> binding.tvStatusLokasi.setText(s));
        viewModel.getStatusCuaca().observe(getViewLifecycleOwner(), s -> binding.tvStatusCuaca.setText(s));
        viewModel.getNamaLokasi().observe(getViewLifecycleOwner(), s -> binding.tvNamaWilayah.setText(s));
        viewModel.getIsLoading().observe(getViewLifecycleOwner(), loading ->
                binding.progressBar.setVisibility(loading ? View.VISIBLE : View.GONE));

        viewModel.getDataCuaca().observe(getViewLifecycleOwner(), data -> {
            if (data == null) return;
            CuacaAdapter adapter = new CuacaAdapter(data);
            binding.rvForecastList.setAdapter(adapter);

            CuacaData.Item f = data.getSelected();
            if (f != null) {
                binding.tvWaktuPrakiraan.setText("Waktu prakiraan terdekat: " + (f.localDatetime != null ? f.localDatetime : ""));
                binding.tvKondisi.setText("Kondisi prakiraan BMKG: " + (f.weatherDesc != null ? f.weatherDesc : "Deskripsi tidak tersedia."));
                binding.tvSuhu.setText(f.t != null ? f.t + " °C" : "Tidak tersedia");
                binding.tvKelembapan.setText(f.hu != null ? f.hu + "%" : "Tidak tersedia");
                binding.tvAngin.setText(f.ws != null ? f.ws + " km/jam" : "Tidak tersedia");
                binding.tvArahAngin.setText(f.wd != null ? f.wd : "Tidak tersedia");
                binding.tvJarakPandang.setText(f.vsText != null ? f.vsText : (f.vs != null ? f.vs : "Tidak tersedia"));
                binding.tvTutupanAwan.setText(f.tcc != null ? f.tcc + "%" : "Tidak tersedia");
                binding.tvCurahHujan.setText(f.tp != null ? f.tp + " mm" : "Tidak tersedia");
            }
        });

        binding.btnGunakanLokasi.setOnClickListener(v -> periksaIzinLokasi());
        binding.btnPerbarui.setOnClickListener(v -> {
            RegionInfo region = viewModel.getCurrentRegion();
            if (region != null) {
                viewModel.ambilPrakiraan(region.code, region);
            } else {
                periksaIzinLokasi();
            }
        });
        binding.btnManual.setOnClickListener(v -> {
            String kode = binding.etAdm4.getText().toString().trim();
            if (kode.isEmpty()) {
                viewModel.setStatusCuacaError("Masukkan kode adm4 terlebih dahulu.");
                return;
            }
            viewModel.ambilPrakiraan(kode, null);
        });
    }

    private void periksaIzinLokasi() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            dapatkanLokasi();
        } else {
            locationPermLauncher.launch(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            });
        }
    }

    private void dapatkanLokasi() {
        viewModel.setStatusLokasi("Mendapatkan koordinat perangkat...");
        try {
            fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
                if (location != null) {
                    prosesLokasi(location);
                } else {
                    viewModel.setStatusLokasi("Lokasi tidak tersedia. Aktifkan GPS lalu coba lagi.");
                }
            }).addOnFailureListener(e ->
                    viewModel.setStatusLokasi("Lokasi gagal ditemukan: " + e.getMessage()));
        } catch (SecurityException e) {
            viewModel.setStatusLokasi("Izin lokasi diperlukan.");
        }
    }

    private void prosesLokasi(Location location) {
        double lat = location.getLatitude();
        double lon = location.getLongitude();
        viewModel.setStatusLokasi("Koordinat diperoleh. Akurasi GPS sekitar "
                + Math.round(location.getAccuracy()) + " meter. Mencari wilayah...");

        new Thread(() -> {
            try {
                GeocodingHelper.AddressResult addr = GeocodingHelper.reverse(lat, lon);
                RegionInfo region = RegionIndexHelper.matchRegion(addr);
                if (region == null) throw new Exception("Wilayah tidak ditemukan pada indeks.");
                String namaLengkap = String.join(", ",
                        region.village, region.district, region.county, region.province)
                        .replaceAll(", ,", ",").replaceAll("^,|,$", "");

                viewModel.setCurrentRegion(region);
                viewModel.setNamaLokasi(namaLengkap);
                viewModel.setStatusLokasi("Wilayah hasil pencarian: " + namaLengkap);
                viewModel.ambilPrakiraan(region.code, region);
            } catch (Exception e) {
                viewModel.setStatusLokasi(e.getMessage() != null ? e.getMessage() : "Gagal mencari wilayah.");
            }
        }).start();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
