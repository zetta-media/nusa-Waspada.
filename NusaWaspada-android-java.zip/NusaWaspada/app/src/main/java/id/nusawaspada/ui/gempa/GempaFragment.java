package id.nusawaspada.ui.gempa;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import id.nusawaspada.databinding.FragmentGempaBinding;

public class GempaFragment extends Fragment {

    private FragmentGempaBinding binding;
    private GempaViewModel viewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentGempaBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireActivity()).get(GempaViewModel.class);

        binding.rvGempaFelt.setLayoutManager(new LinearLayoutManager(requireContext()));

        viewModel.getStatusGempa().observe(getViewLifecycleOwner(), s ->
                binding.tvStatusGempa.setText(s));

        viewModel.getIsLoading().observe(getViewLifecycleOwner(), loading ->
                binding.progressBar.setVisibility(loading ? View.VISIBLE : View.GONE));

        viewModel.getLatestQuake().observe(getViewLifecycleOwner(), gempa -> {
            if (gempa == null) return;
            binding.tvLatestTanggal.setText("Tanggal: " + notEmpty(gempa.tanggal));
            binding.tvLatestJam.setText("Waktu: " + notEmpty(gempa.jam));
            binding.tvLatestMag.setText("Magnitudo: " + notEmpty(gempa.magnitude));
            binding.tvLatestKedalaman.setText("Kedalaman: " + notEmpty(gempa.kedalaman));
            binding.tvLatestWilayah.setText("Lokasi: " + notEmpty(gempa.wilayah));
            binding.tvLatestKoordinat.setText("Koordinat: " + notEmpty(gempa.coordinates));
            binding.tvLatestPotensi.setText("Potensi tsunami: " + notEmpty(gempa.potensi));
            binding.tvLatestDirasakan.setText("Dirasakan: " + notEmpty(gempa.dirasakan));
        });

        viewModel.getFeltQuakes().observe(getViewLifecycleOwner(), list -> {
            if (list == null || list.isEmpty()) {
                binding.tvNoFelt.setVisibility(View.VISIBLE);
                binding.rvGempaFelt.setVisibility(View.GONE);
            } else {
                binding.tvNoFelt.setVisibility(View.GONE);
                binding.rvGempaFelt.setVisibility(View.VISIBLE);
                binding.rvGempaFelt.setAdapter(new GempaAdapter(list));
            }
        });

        binding.btnPerbarui.setOnClickListener(v -> viewModel.muatGempa());

        // Auto-load jika belum ada data
        if (viewModel.getLatestQuake().getValue() == null) {
            viewModel.muatGempa();
        }
    }

    private String notEmpty(String v) {
        return (v != null && !v.isEmpty()) ? v : "Tidak tersedia";
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
