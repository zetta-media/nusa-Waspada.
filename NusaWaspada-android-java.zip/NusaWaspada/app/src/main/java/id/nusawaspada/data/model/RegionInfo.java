package id.nusawaspada.data.model;

public class RegionInfo {
    public String code;
    public String village;
    public String district;
    public String county;
    public String province;

    public RegionInfo(String code, String village, String district, String county, String province) {
        this.code = code;
        this.village = village;
        this.district = district;
        this.county = county;
        this.province = province;
    }
}
