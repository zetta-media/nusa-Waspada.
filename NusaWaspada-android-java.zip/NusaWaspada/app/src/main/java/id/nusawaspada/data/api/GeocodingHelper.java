package id.nusawaspada.data.api;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Reverse geocoding menggunakan OpenStreetMap Nominatim.
 */
public class GeocodingHelper {

    private static final String NOMINATIM_URL = "https://nominatim.openstreetmap.org/reverse";
    private static final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build();

    public static class AddressResult {
        public String village;
        public String district;
        public String county;
        public String province;
    }

    /**
     * Synchronous reverse geocoding — panggil dari background thread.
     */
    public static AddressResult reverse(double lat, double lon) throws IOException {
        String url = NOMINATIM_URL
                + "?format=jsonv2"
                + "&lat=" + lat
                + "&lon=" + lon
                + "&zoom=18"
                + "&addressdetails=1";

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Accept", "application/json")
                .addHeader("User-Agent", "NusaWaspada-Android/1.4.0")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("Pencarian nama wilayah gagal. HTTP " + response.code());
            String body = response.body().string();
            JsonObject json = JsonParser.parseString(body).getAsJsonObject();
            if (!json.has("address"))
                throw new IOException("Nama wilayah tidak ditemukan dari koordinat.");

            JsonObject addr = json.getAsJsonObject("address");
            AddressResult result = new AddressResult();
            result.village = getFirst(addr, "village", "suburb", "neighbourhood", "hamlet", "quarter", "town");
            result.district = getFirst(addr, "city_district", "district", "municipality");
            result.county = getFirst(addr, "county", "city", "town");
            result.province = getFirst(addr, "state");
            return result;
        }
    }

    private static String getFirst(JsonObject addr, String... keys) {
        for (String key : keys) {
            if (addr.has(key) && !addr.get(key).isJsonNull()) {
                String v = addr.get(key).getAsString().trim();
                if (!v.isEmpty()) return v;
            }
        }
        return "";
    }
}
