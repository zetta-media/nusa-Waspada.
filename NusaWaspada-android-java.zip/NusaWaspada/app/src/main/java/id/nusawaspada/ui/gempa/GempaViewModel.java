package id.nusawaspada.ui.gempa;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import id.nusawaspada.data.api.BmkgRepository;
import id.nusawaspada.data.model.GempaModel;

import java.util.List;

public class GempaViewModel extends ViewModel {

    private final MutableLiveData<String> statusGempa = new MutableLiveData<>("Memuat informasi gempa...");
    private final MutableLiveData<GempaModel> latestQuake = new MutableLiveData<>();
    private final MutableLiveData<List<GempaModel>> feltQuakes = new MutableLiveData<>();
    private final MutableLiveData<String> ringkasanGempa = new MutableLiveData<>("Informasi gempa belum dimuat.");
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);

    private final BmkgRepository repository;

    public GempaViewModel() {
        repository = new BmkgRepository();
    }

    public LiveData<String> getStatusGempa() { return statusGempa; }
    public LiveData<GempaModel> getLatestQuake() { return latestQuake; }
    public LiveData<List<GempaModel>> getFeltQuakes() { return feltQuakes; }
    public LiveData<String> getRingkasanGempa() { return ringkasanGempa; }
    public LiveData<Boolean> getIsLoading() { return isLoading; }

    public void muatGempa() {
        isLoading.postValue(true);
        statusGempa.postValue("Mengambil informasi gempa BMKG...");

        repository.fetchQuakes(new BmkgRepository.QuakeCallback() {
            @Override
            public void onSuccess(GempaModel latest, List<GempaModel> felt) {
                isLoading.postValue(false);
                latestQuake.postValue(latest);
                feltQuakes.postValue(felt);
                statusGempa.postValue("Informasi gempa berhasil diambil dari layanan BMKG.");
                ringkasanGempa.postValue("Gempa terbaru BMKG: magnitudo "
                        + (latest.magnitude != null && !latest.magnitude.isEmpty() ? latest.magnitude : "tidak tersedia")
                        + ", " + (latest.wilayah != null && !latest.wilayah.isEmpty() ? latest.wilayah : "lokasi tidak tersedia") + ".");
            }

            @Override
            public void onError(String error) {
                isLoading.postValue(false);
                statusGempa.postValue(error + " Periksa koneksi internet.");
            }
        });
    }
}
