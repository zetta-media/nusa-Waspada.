package id.nusawaspada.data.model;

public class GempaModel {
    public String tanggal;
    public String jam;
    public String magnitude;
    public String kedalaman;
    public String wilayah;
    public String coordinates;
    public String lintang;
    public String bujur;
    public String potensi;
    public String dirasakan;
    public String shakemap;

    public GempaModel() {}
}
