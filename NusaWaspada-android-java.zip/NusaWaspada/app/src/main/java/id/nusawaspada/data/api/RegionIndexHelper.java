package id.nusawaspada.data.api;

import id.nusawaspada.data.model.RegionInfo;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Memuat indeks kode adm4 BMKG dari GitHub dan mencocokkan nama wilayah.
 */
public class RegionIndexHelper {

    private static final String REGION_INDEX_URL =
            "https://raw.githubusercontent.com/dwirx/bmkg-api/main/base.csv";

    private static List<RegionRow> cachedRows = null;

    private static final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build();

    private static class RegionRow {
        String code;
        String name;
        String key;
        int level;
    }

    /**
     * Synchronous — panggil dari background thread.
     */
    public static RegionInfo matchRegion(GeocodingHelper.AddressResult addr) throws Exception {
        if (addr.village == null || addr.village.isEmpty())
            throw new Exception("Nama desa atau kelurahan tidak ditemukan dari GPS. Gunakan kode adm4 manual.");

        List<RegionRow> rows = loadIndex();
        String normVillage = norm(addr.village);
        List<RegionRow> candidates = new ArrayList<>();
        for (RegionRow row : rows) {
            if (row.level == 4 && row.key.equals(normVillage)) candidates.add(row);
        }

        if (candidates.size() > 1 && !addr.district.isEmpty()) {
            String normDistrict = norm(addr.district);
            List<RegionRow> filtered = new ArrayList<>();
            for (RegionRow c : candidates) {
                String parentCode = parentCode(c.code, 3);
                for (RegionRow r : rows) {
                    if (r.code.equals(parentCode) && r.key.equals(normDistrict)) {
                        filtered.add(c); break;
                    }
                }
            }
            if (!filtered.isEmpty()) candidates = filtered;
        }

        if (candidates.size() > 1 && !addr.county.isEmpty()) {
            String normCounty = norm(addr.county);
            List<RegionRow> filtered = new ArrayList<>();
            for (RegionRow c : candidates) {
                String parentCode = parentCode(c.code, 2);
                for (RegionRow r : rows) {
                    if (r.code.equals(parentCode) && r.key.equals(normCounty)) {
                        filtered.add(c); break;
                    }
                }
            }
            if (!filtered.isEmpty()) candidates = filtered;
        }

        if (candidates.size() == 1) {
            RegionRow r = candidates.get(0);
            return new RegionInfo(r.code, addr.village, addr.district, addr.county, addr.province);
        } else if (candidates.size() > 1) {
            throw new Exception("Nama desa cocok dengan lebih dari satu wilayah. Masukkan kode adm4 yang benar.");
        } else {
            throw new Exception("Kode desa tidak ditemukan pada indeks. Masukkan kode adm4 yang benar.");
        }
    }

    private static synchronized List<RegionRow> loadIndex() throws IOException {
        if (cachedRows != null) return cachedRows;

        Request request = new Request.Builder()
                .url(REGION_INDEX_URL)
                .addHeader("Cache-Control", "no-cache")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("Indeks kode wilayah eksternal gagal diakses.");
            String text = response.body().string();
            String[] lines = text.split("\\r?\\n");
            if (lines.length < 2)
                throw new IOException("Indeks kode wilayah kosong.");

            List<RegionRow> out = new ArrayList<>();
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                String[] fields = parseCsvLine(line);
                if (fields.length < 2) continue;
                String code = fields[0].trim();
                String name = fields[1].trim();
                String[] parts = code.split("\\.");
                if (code.isEmpty() || name.isEmpty() || parts.length < 1 || parts.length > 4) continue;
                RegionRow row = new RegionRow();
                row.code = code;
                row.name = name;
                row.key = norm(name);
                row.level = parts.length;
                out.add(row);
            }

            if (out.isEmpty())
                throw new IOException("Format indeks kode wilayah tidak dikenali. Masukkan kode adm4 manual.");

            cachedRows = out;
            return out;
        }
    }

    private static String parentCode(String code, int depth) {
        String[] parts = code.split("\\.");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(depth, parts.length); i++) {
            if (sb.length() > 0) sb.append(".");
            sb.append(parts[i]);
        }
        return sb.toString();
    }

    private static String[] parseCsvLine(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    current.append('"'); i++;
                } else inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                out.add(current.toString().trim());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        out.add(current.toString().trim());
        return out.toArray(new String[0]);
    }

    public static String norm(String v) {
        if (v == null) return "";
        return Normalizer.normalize(v, Normalizer.Form.NFD)
                .replaceAll("[\\u0300-\\u036f]", "")
                .toLowerCase()
                .replaceAll("\\b(kabupaten|kab\\.|kota administrasi|kota|kecamatan|kec\\.|desa|kelurahan|kel\\.|provinsi|prov\\.)\\b", "")
                .replaceAll("[^a-z0-9]", "");
    }
}
