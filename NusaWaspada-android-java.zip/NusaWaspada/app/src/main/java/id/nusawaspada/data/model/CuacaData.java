package id.nusawaspada.data.model;

import java.util.List;

public class CuacaData {

    private Item selected;
    private List<Item> upcoming;
    private String kodeAdm4;
    private String namaWilayah;

    public CuacaData(Item selected, List<Item> upcoming, String kodeAdm4, String namaWilayah) {
        this.selected = selected;
        this.upcoming = upcoming;
        this.kodeAdm4 = kodeAdm4;
        this.namaWilayah = namaWilayah;
    }

    public Item getSelected() { return selected; }
    public List<Item> getUpcoming() { return upcoming; }
    public String getKodeAdm4() { return kodeAdm4; }
    public String getNamaWilayah() { return namaWilayah; }

    public static class Item {
        public String localDatetime;
        public String datetime;
        public String weatherDesc;
        public String weatherDescEn;
        public String t;      // suhu
        public String hu;     // kelembapan
        public String ws;     // kecepatan angin
        public String wd;     // arah angin
        public String vs;     // jarak pandang
        public String vsText;
        public String tcc;    // tutupan awan
        public String tp;     // curah hujan
        public String analysisDate;
        public String timezone;
    }
}
