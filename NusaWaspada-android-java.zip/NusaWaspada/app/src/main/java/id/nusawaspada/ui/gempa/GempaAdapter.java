package id.nusawaspada.ui.gempa;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import id.nusawaspada.R;
import id.nusawaspada.data.model.GempaModel;

import java.util.List;

public class GempaAdapter extends RecyclerView.Adapter<GempaAdapter.ViewHolder> {

    private final List<GempaModel> items;

    public GempaAdapter(List<GempaModel> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_gempa, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        GempaModel g = items.get(position);
        holder.tvIndex.setText("Gempa " + (position + 1));
        holder.tvMag.setText("Magnitudo: " + ne(g.magnitude));
        holder.tvTanggal.setText("Tanggal: " + ne(g.tanggal) + " " + ne(g.jam));
        holder.tvWilayah.setText("Lokasi: " + ne(g.wilayah));
        holder.tvPotensi.setText("Potensi tsunami: " + ne(g.potensi));
        holder.tvDirasakan.setText("Dirasakan: " + ne(g.dirasakan));
    }

    @Override
    public int getItemCount() { return items.size(); }

    private String ne(String v) {
        return (v != null && !v.isEmpty()) ? v : "Tidak tersedia";
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvIndex, tvMag, tvTanggal, tvWilayah, tvPotensi, tvDirasakan;
        ViewHolder(View v) {
            super(v);
            tvIndex = v.findViewById(R.id.tv_gempa_index);
            tvMag = v.findViewById(R.id.tv_gempa_mag);
            tvTanggal = v.findViewById(R.id.tv_gempa_tanggal);
            tvWilayah = v.findViewById(R.id.tv_gempa_wilayah);
            tvPotensi = v.findViewById(R.id.tv_gempa_potensi);
            tvDirasakan = v.findViewById(R.id.tv_gempa_dirasakan);
        }
    }
}
