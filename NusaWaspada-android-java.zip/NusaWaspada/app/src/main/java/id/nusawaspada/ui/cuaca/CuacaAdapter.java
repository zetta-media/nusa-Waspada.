package id.nusawaspada.ui.cuaca;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import id.nusawaspada.R;
import id.nusawaspada.data.model.CuacaData;

import java.util.List;

public class CuacaAdapter extends RecyclerView.Adapter<CuacaAdapter.ViewHolder> {

    private final List<CuacaData.Item> items;

    public CuacaAdapter(CuacaData data) {
        // Show upcoming forecasts (max 12)
        List<CuacaData.Item> upcoming = data.getUpcoming();
        this.items = upcoming.subList(0, Math.min(12, upcoming.size()));
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cuaca, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CuacaData.Item f = items.get(position);
        String dt = f.localDatetime != null ? f.localDatetime : (f.datetime != null ? f.datetime : "Waktu tidak tersedia");
        holder.tvWaktu.setText(dt);
        holder.tvKondisi.setText(f.weatherDesc != null ? f.weatherDesc : "Deskripsi tidak tersedia");
        holder.tvSuhu.setText("Suhu: " + ne(f.t, "°C"));
        holder.tvKelembapan.setText("Kelembapan: " + ne(f.hu, "%"));
        holder.tvAngin.setText("Angin: " + ne(f.ws, "km/jam"));
    }

    @Override
    public int getItemCount() { return items.size(); }

    private String ne(String v, String suffix) {
        return (v != null && !v.isEmpty()) ? v + " " + suffix : "Tidak tersedia";
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvWaktu, tvKondisi, tvSuhu, tvKelembapan, tvAngin;
        ViewHolder(View v) {
            super(v);
            tvWaktu = v.findViewById(R.id.tv_cuaca_waktu);
            tvKondisi = v.findViewById(R.id.tv_cuaca_kondisi);
            tvSuhu = v.findViewById(R.id.tv_cuaca_suhu);
            tvKelembapan = v.findViewById(R.id.tv_cuaca_kelembapan);
            tvAngin = v.findViewById(R.id.tv_cuaca_angin);
        }
    }
}
