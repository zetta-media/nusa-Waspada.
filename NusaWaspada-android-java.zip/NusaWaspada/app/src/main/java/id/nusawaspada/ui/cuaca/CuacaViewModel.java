package id.nusawaspada.ui.cuaca;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import id.nusawaspada.data.api.BmkgRepository;
import id.nusawaspada.data.model.CuacaData;
import id.nusawaspada.data.model.RegionInfo;

public class CuacaViewModel extends ViewModel {

    private final MutableLiveData<String> statusLokasi = new MutableLiveData<>("Lokasi belum diperiksa.");
    private final MutableLiveData<String> statusCuaca = new MutableLiveData<>("Prakiraan belum dimuat.");
    private final MutableLiveData<String> namaLokasi = new MutableLiveData<>("Belum ada wilayah terverifikasi.");
    private final MutableLiveData<CuacaData> dataCuaca = new MutableLiveData<>();
    private final MutableLiveData<String> ringkasanCuaca = new MutableLiveData<>("Prakiraan cuaca belum dimuat.");
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>(false);

    private RegionInfo currentRegion = null;
    private final BmkgRepository repository;

    public CuacaViewModel() {
        repository = new BmkgRepository();
    }

    // --- Getters ---
    public LiveData<String> getStatusLokasi() { return statusLokasi; }
    public LiveData<String> getStatusCuaca() { return statusCuaca; }
    public LiveData<String> getNamaLokasi() { return namaLokasi; }
    public LiveData<CuacaData> getDataCuaca() { return dataCuaca; }
    public LiveData<String> getRingkasanCuaca() { return ringkasanCuaca; }
    public LiveData<Boolean> getIsLoading() { return isLoading; }
    public RegionInfo getCurrentRegion() { return currentRegion; }

    // --- Setters (called from Fragment) ---
    public void setStatusLokasi(String msg) { statusLokasi.postValue(msg); }
    public void setStatusCuacaError(String msg) { statusCuaca.postValue(msg); }
    public void setNamaLokasi(String nama) { namaLokasi.postValue(nama); }
    public void setCurrentRegion(RegionInfo region) { this.currentRegion = region; }

    public void ambilPrakiraan(String kodeAdm4, RegionInfo expectedRegion) {
        isLoading.postValue(true);
        statusCuaca.postValue("Mengambil data prakiraan BMKG...");

        repository.fetchWeather(kodeAdm4, expectedRegion, new BmkgRepository.WeatherCallback() {
            @Override
            public void onSuccess(CuacaData data, String namaWilayah) {
                isLoading.postValue(false);
                dataCuaca.postValue(data);
                namaLokasi.postValue(namaWilayah);
                statusCuaca.postValue("Data prakiraan berhasil diambil dari API BMKG untuk wilayah " + namaWilayah + ".");
                ringkasanCuaca.postValue(buildRingkasan(data, namaWilayah));
            }

            @Override
            public void onError(String error) {
                isLoading.postValue(false);
                statusCuaca.postValue(error + " Data cuaca tidak direkayasa.");
                ringkasanCuaca.postValue("Prakiraan tidak tersedia karena data gagal diverifikasi.");
            }
        });
    }

    private String buildRingkasan(CuacaData data, String namaWilayah) {
        if (data == null || data.getSelected() == null) return "Data prakiraan tidak tersedia.";
        CuacaData.Item f = data.getSelected();
        return "Prakiraan BMKG untuk " + namaWilayah + ": "
                + (f.weatherDesc != null ? f.weatherDesc : "kondisi tidak tersedia")
                + ", suhu " + (f.t != null ? f.t + " °C" : "tidak tersedia")
                + ", untuk " + (f.localDatetime != null ? f.localDatetime : "");
    }
}
