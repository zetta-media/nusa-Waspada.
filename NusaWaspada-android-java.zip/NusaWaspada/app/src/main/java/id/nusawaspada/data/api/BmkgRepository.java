package id.nusawaspada.data.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import id.nusawaspada.data.model.CuacaData;
import id.nusawaspada.data.model.GempaModel;
import id.nusawaspada.data.model.RegionInfo;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class BmkgRepository {

    private static final String API_WEATHER = "https://api.bmkg.go.id/publik/prakiraan-cuaca?adm4=";
    private static final String API_QUAKE = "https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json";
    private static final String API_FELT = "https://data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json";

    private final OkHttpClient client;

    public BmkgRepository() {
        client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build();
    }

    // ===== WEATHER =====

    public interface WeatherCallback {
        void onSuccess(CuacaData data, String namaWilayah);
        void onError(String error);
    }

    public void fetchWeather(String kodeAdm4, RegionInfo expectedRegion, WeatherCallback callback) {
        if (!kodeAdm4.matches("\\d{1,2}\\.\\d{1,2}\\.\\d{1,2}\\.\\d{1,4}")) {
            callback.onError("Format kode adm4 tidak valid.");
            return;
        }

        Request request = new Request.Builder()
                .url(API_WEATHER + kodeAdm4)
                .addHeader("Cache-Control", "no-cache")
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onError("Koneksi ke API BMKG gagal: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onError("API BMKG memberi status HTTP " + response.code() + ".");
                    return;
                }
                String body = response.body().string();
                try {
                    parseAndVerifyWeather(body, kodeAdm4, expectedRegion, callback);
                } catch (Exception e) {
                    callback.onError(e.getMessage() != null ? e.getMessage() : "Gagal memproses data BMKG.");
                }
            }
        });
    }

    private void parseAndVerifyWeather(String json, String kodeAdm4, RegionInfo expected,
                                        WeatherCallback callback) throws Exception {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        JsonArray dataArr = root.getAsJsonArray("data");
        if (dataArr == null || dataArr.size() == 0)
            throw new Exception("Respons BMKG tidak berisi data prakiraan.");

        JsonObject lokasi = null;
        if (root.has("lokasi")) {
            lokasi = root.getAsJsonObject("lokasi");
        } else if (dataArr.size() > 0 && dataArr.get(0).getAsJsonObject().has("lokasi")) {
            lokasi = dataArr.get(0).getAsJsonObject().getAsJsonObject("lokasi");
        }
        if (lokasi == null) throw new Exception("Data lokasi tidak ditemukan.");

        String returnedAdm4 = getStr(lokasi, "adm4");
        if (!kodeAdm4.equals(returnedAdm4))
            throw new Exception("Kode wilayah tidak dapat diverifikasi dari respons BMKG. Prakiraan dibatalkan.");

        String desa = getStr(lokasi, "desa");
        if (desa.isEmpty()) throw new Exception("Nama desa tidak tersedia pada respons BMKG. Prakiraan dibatalkan.");

        if (expected != null && !norm(desa).equals(norm(expected.village)))
            throw new Exception("Nama desa dari BMKG tidak cocok dengan hasil lokasi. Prakiraan dibatalkan.");

        List<CuacaData.Item> list = flattenForecasts(dataArr);
        if (list.isEmpty()) throw new Exception("Waktu prakiraan tidak ditemukan dalam respons BMKG.");

        String timezone = lokasi.has("timezone") ? getStr(lokasi, "timezone") : "";
        ChoiceResult choice = chooseForecasts(list, timezone);
        if (choice == null) throw new Exception("Tidak ada waktu prakiraan yang dapat dipilih.");

        String namaWilayah = joinNonEmpty(
                getStr(lokasi, "desa"),
                getStr(lokasi, "kecamatan"),
                getStr(lokasi, "kotkab"),
                getStr(lokasi, "provinsi"));

        CuacaData data = new CuacaData(choice.selected, choice.upcoming, kodeAdm4, namaWilayah);
        callback.onSuccess(data, namaWilayah);
    }

    private List<CuacaData.Item> flattenForecasts(JsonArray dataArr) {
        List<CuacaData.Item> list = new ArrayList<>();
        for (JsonElement groupEl : dataArr) {
            JsonObject group = groupEl.getAsJsonObject();
            if (!group.has("cuaca")) continue;
            for (JsonElement dayEl : group.getAsJsonArray("cuaca")) {
                if (dayEl.isJsonArray()) {
                    for (JsonElement itemEl : dayEl.getAsJsonArray()) {
                        if (itemEl.isJsonObject()) list.add(parseItem(itemEl.getAsJsonObject()));
                    }
                } else if (dayEl.isJsonObject()) {
                    list.add(parseItem(dayEl.getAsJsonObject()));
                }
            }
        }
        list.sort(Comparator.comparing(i -> (i.localDatetime != null ? i.localDatetime : i.datetime != null ? i.datetime : "")));
        return list;
    }

    private CuacaData.Item parseItem(JsonObject o) {
        CuacaData.Item i = new CuacaData.Item();
        i.localDatetime = getStr(o, "local_datetime");
        i.datetime = getStr(o, "datetime");
        i.weatherDesc = getStr(o, "weather_desc");
        i.weatherDescEn = getStr(o, "weather_desc_en");
        i.t = getStr(o, "t");
        i.hu = getStr(o, "hu");
        i.ws = getStr(o, "ws");
        i.wd = getStr(o, "wd");
        i.vs = getStr(o, "vs");
        i.vsText = getStr(o, "vs_text");
        i.tcc = getStr(o, "tcc");
        i.tp = getStr(o, "tp");
        i.analysisDate = getStr(o, "analysis_date");
        i.timezone = getStr(o, "timezone");
        return i;
    }

    private static class ChoiceResult {
        CuacaData.Item selected;
        List<CuacaData.Item> upcoming;
    }

    private ChoiceResult chooseForecasts(List<CuacaData.Item> list, String timezone) {
        if (list.isEmpty()) return null;
        String now = nowWallClock();
        CuacaData.Item selected = null;
        for (CuacaData.Item item : list) {
            String dt = item.localDatetime != null ? item.localDatetime : item.datetime;
            if (dt != null && dt.compareTo(now) >= 0) { selected = item; break; }
        }
        if (selected == null) selected = list.get(list.size() - 1);
        final CuacaData.Item finalSelected = selected;
        String selDt = finalSelected.localDatetime != null ? finalSelected.localDatetime : finalSelected.datetime != null ? finalSelected.datetime : "";
        List<CuacaData.Item> upcoming = new ArrayList<>();
        for (CuacaData.Item item : list) {
            String dt = item.localDatetime != null ? item.localDatetime : item.datetime != null ? item.datetime : "";
            if (dt.compareTo(selDt) >= 0) upcoming.add(item);
        }
        ChoiceResult r = new ChoiceResult();
        r.selected = selected;
        r.upcoming = upcoming;
        return r;
    }

    private String nowWallClock() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US);
        return sdf.format(new java.util.Date());
    }

    // ===== EARTHQUAKE =====

    public interface QuakeCallback {
        void onSuccess(GempaModel latest, List<GempaModel> felt);
        void onError(String error);
    }

    public void fetchQuakes(QuakeCallback callback) {
        fetchLatestQuake(callback);
    }

    private void fetchLatestQuake(QuakeCallback callback) {
        Request req = new Request.Builder().url(API_QUAKE).addHeader("Cache-Control", "no-cache").build();
        client.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                callback.onError("Layanan gempa BMKG tidak merespons: " + e.getMessage());
            }
            @Override public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    callback.onError("Layanan gempa BMKG memberi status " + response.code());
                    return;
                }
                String body = response.body().string();
                try {
                    JsonObject root = JsonParser.parseString(body).getAsJsonObject();
                    JsonObject gempaObj = root.getAsJsonObject("Infogempa").getAsJsonObject("gempa");
                    GempaModel latest = parseGempa(gempaObj);
                    fetchFeltQuakes(latest, callback);
                } catch (Exception e) {
                    callback.onError("Data gempa terbaru tidak ditemukan.");
                }
            }
        });
    }

    private void fetchFeltQuakes(GempaModel latest, QuakeCallback callback) {
        Request req = new Request.Builder().url(API_FELT).addHeader("Cache-Control", "no-cache").build();
        client.newCall(req).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                callback.onSuccess(latest, new ArrayList<>());
            }
            @Override public void onResponse(Call call, Response response) throws IOException {
                List<GempaModel> felt = new ArrayList<>();
                if (response.isSuccessful()) {
                    try {
                        String body = response.body().string();
                        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
                        JsonElement gempaEl = root.getAsJsonObject("Infogempa").get("gempa");
                        if (gempaEl.isJsonArray()) {
                            for (JsonElement el : gempaEl.getAsJsonArray()) {
                                felt.add(parseGempa(el.getAsJsonObject()));
                            }
                        } else if (gempaEl.isJsonObject()) {
                            felt.add(parseGempa(gempaEl.getAsJsonObject()));
                        }
                    } catch (Exception ignored) {}
                }
                callback.onSuccess(latest, felt);
            }
        });
    }

    private GempaModel parseGempa(JsonObject o) {
        GempaModel g = new GempaModel();
        g.tanggal = getStr(o, "Tanggal");
        g.jam = getStr(o, "Jam");
        g.magnitude = getStr(o, "Magnitude");
        g.kedalaman = getStr(o, "Kedalaman");
        g.wilayah = getStr(o, "Wilayah");
        g.coordinates = getStr(o, "Coordinates");
        g.lintang = getStr(o, "Lintang");
        g.bujur = getStr(o, "Bujur");
        g.potensi = getStr(o, "Potensi");
        g.dirasakan = getStr(o, "Dirasakan");
        g.shakemap = getStr(o, "Shakemap");
        return g;
    }

    // ===== Helpers =====

    private String getStr(JsonObject o, String key) {
        if (o == null || !o.has(key) || o.get(key).isJsonNull()) return "";
        return o.get(key).getAsString().trim();
    }

    private String joinNonEmpty(String... parts) {
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p != null && !p.isEmpty()) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(p);
            }
        }
        return sb.toString();
    }

    public static String norm(String v) {
        if (v == null) return "";
        String normalized = Normalizer.normalize(v, Normalizer.Form.NFD)
                .replaceAll("[\\u0300-\\u036f]", "")
                .toLowerCase()
                .replaceAll("\\b(kabupaten|kab\\.|kota administrasi|kota|kecamatan|kec\\.|desa|kelurahan|kel\\.|provinsi|prov\\.)\\b", "")
                .replaceAll("[^a-z0-9]", "");
        return normalized;
    }
}
