# Add project specific ProGuard rules here.
-keep class id.nusawaspada.data.model.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn okio.**
